<?php
/**
 * Helpher untuk menampilkan identitas aplikasi
 *
 * @package CodeIgniter
 * @category Helpers
 * @author Ardi Tri Heru (arditriheruh@gmail.com)
 * @link https://github.com/arditriheru
 */
if (!function_exists('getWebsite')) {
	function getWebsite(){
		$getWebsite = "www.arditriheru.com";
		return $getWebsite;
	}
}

if (!function_exists('getTopTitle')) {
	function getTopTitle(){
		$getTopTitle = "Invitaco | Undangan Online | Undangan Digital";
		return $getTopTitle;
	}
}

if (!function_exists('getCopyright')) {
	function getCopyright(){
		$getCopyright = "Invitaco";
		return $getCopyright;
	}
}

if (!function_exists('getVersion')) {
	function getVersion(){
		$getVersion = "v1 CI";
		return $getVersion;
	}
}

?>